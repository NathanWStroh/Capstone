﻿namespace com.Farouche
{
    partial class frmViewOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabPackList = new System.Windows.Forms.TabControl();
            this.tabAllOrders = new System.Windows.Forms.TabPage();
            this.btnClearUser = new System.Windows.Forms.Button();
            this.lvAllOrders = new System.Windows.Forms.ListView();
            this.tabPickList = new System.Windows.Forms.TabPage();
            this.lvPickList = new System.Windows.Forms.ListView();
            this.btnStartPick = new System.Windows.Forms.Button();
            this.tabMyOrders = new System.Windows.Forms.TabPage();
            this.btnDetails = new System.Windows.Forms.Button();
            this.lvMyOrders = new System.Windows.Forms.ListView();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnPackComplete = new System.Windows.Forms.Button();
            this.lvPackList = new System.Windows.Forms.ListView();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.lnkInventory = new System.Windows.Forms.LinkLabel();
            this.tabPackList.SuspendLayout();
            this.tabAllOrders.SuspendLayout();
            this.tabPickList.SuspendLayout();
            this.tabMyOrders.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPackList
            // 
            this.tabPackList.Controls.Add(this.tabAllOrders);
            this.tabPackList.Controls.Add(this.tabPickList);
            this.tabPackList.Controls.Add(this.tabMyOrders);
            this.tabPackList.Controls.Add(this.tabPage1);
            this.tabPackList.Location = new System.Drawing.Point(12, 52);
            this.tabPackList.Name = "tabPackList";
            this.tabPackList.SelectedIndex = 0;
            this.tabPackList.Size = new System.Drawing.Size(715, 344);
            this.tabPackList.TabIndex = 0;
            // 
            // tabAllOrders
            // 
            this.tabAllOrders.Controls.Add(this.btnClearUser);
            this.tabAllOrders.Controls.Add(this.lvAllOrders);
            this.tabAllOrders.Location = new System.Drawing.Point(4, 22);
            this.tabAllOrders.Name = "tabAllOrders";
            this.tabAllOrders.Padding = new System.Windows.Forms.Padding(3);
            this.tabAllOrders.Size = new System.Drawing.Size(707, 318);
            this.tabAllOrders.TabIndex = 0;
            this.tabAllOrders.Text = "All Orders";
            this.tabAllOrders.UseVisualStyleBackColor = true;
            // 
            // btnClearUser
            // 
            this.btnClearUser.Location = new System.Drawing.Point(20, 281);
            this.btnClearUser.Name = "btnClearUser";
            this.btnClearUser.Size = new System.Drawing.Size(75, 23);
            this.btnClearUser.TabIndex = 1;
            this.btnClearUser.Text = "Clear User";
            this.btnClearUser.UseVisualStyleBackColor = true;
            this.btnClearUser.Click += new System.EventHandler(this.btnClearUser_Click);
            // 
            // lvAllOrders
            // 
            this.lvAllOrders.Location = new System.Drawing.Point(20, 19);
            this.lvAllOrders.Name = "lvAllOrders";
            this.lvAllOrders.Size = new System.Drawing.Size(665, 236);
            this.lvAllOrders.TabIndex = 0;
            this.lvAllOrders.UseCompatibleStateImageBehavior = false;
            // 
            // tabPickList
            // 
            this.tabPickList.Controls.Add(this.lvPickList);
            this.tabPickList.Controls.Add(this.btnStartPick);
            this.tabPickList.Location = new System.Drawing.Point(4, 22);
            this.tabPickList.Name = "tabPickList";
            this.tabPickList.Padding = new System.Windows.Forms.Padding(3);
            this.tabPickList.Size = new System.Drawing.Size(707, 318);
            this.tabPickList.TabIndex = 1;
            this.tabPickList.Text = "Pick List";
            this.tabPickList.UseVisualStyleBackColor = true;
            // 
            // lvPickList
            // 
            this.lvPickList.Location = new System.Drawing.Point(16, 24);
            this.lvPickList.Name = "lvPickList";
            this.lvPickList.Size = new System.Drawing.Size(673, 229);
            this.lvPickList.TabIndex = 2;
            this.lvPickList.UseCompatibleStateImageBehavior = false;
            // 
            // btnStartPick
            // 
            this.btnStartPick.Location = new System.Drawing.Point(563, 274);
            this.btnStartPick.Name = "btnStartPick";
            this.btnStartPick.Size = new System.Drawing.Size(126, 23);
            this.btnStartPick.TabIndex = 1;
            this.btnStartPick.Text = "Start Pick";
            this.btnStartPick.UseVisualStyleBackColor = true;
            this.btnStartPick.Click += new System.EventHandler(this.btnStartPick_Click);
            // 
            // tabMyOrders
            // 
            this.tabMyOrders.Controls.Add(this.btnDetails);
            this.tabMyOrders.Controls.Add(this.lvMyOrders);
            this.tabMyOrders.Location = new System.Drawing.Point(4, 22);
            this.tabMyOrders.Name = "tabMyOrders";
            this.tabMyOrders.Padding = new System.Windows.Forms.Padding(3);
            this.tabMyOrders.Size = new System.Drawing.Size(707, 318);
            this.tabMyOrders.TabIndex = 2;
            this.tabMyOrders.Text = "My Orders";
            this.tabMyOrders.UseVisualStyleBackColor = true;
            // 
            // btnDetails
            // 
            this.btnDetails.Location = new System.Drawing.Point(538, 273);
            this.btnDetails.Name = "btnDetails";
            this.btnDetails.Size = new System.Drawing.Size(149, 23);
            this.btnDetails.TabIndex = 1;
            this.btnDetails.Text = "View Details";
            this.btnDetails.UseVisualStyleBackColor = true;
            this.btnDetails.Click += new System.EventHandler(this.btnDetails_Click);
            // 
            // lvMyOrders
            // 
            this.lvMyOrders.Location = new System.Drawing.Point(17, 18);
            this.lvMyOrders.Name = "lvMyOrders";
            this.lvMyOrders.Size = new System.Drawing.Size(670, 233);
            this.lvMyOrders.TabIndex = 0;
            this.lvMyOrders.UseCompatibleStateImageBehavior = false;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnPackComplete);
            this.tabPage1.Controls.Add(this.lvPackList);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(707, 318);
            this.tabPage1.TabIndex = 3;
            this.tabPage1.Text = "Pack List";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnPackComplete
            // 
            this.btnPackComplete.Location = new System.Drawing.Point(516, 280);
            this.btnPackComplete.Name = "btnPackComplete";
            this.btnPackComplete.Size = new System.Drawing.Size(157, 23);
            this.btnPackComplete.TabIndex = 1;
            this.btnPackComplete.Text = "Ready for Ship";
            this.btnPackComplete.UseVisualStyleBackColor = true;
            // 
            // lvPackList
            // 
            this.lvPackList.Location = new System.Drawing.Point(33, 24);
            this.lvPackList.Name = "lvPackList";
            this.lvPackList.Size = new System.Drawing.Size(633, 202);
            this.lvPackList.TabIndex = 0;
            this.lvPackList.UseCompatibleStateImageBehavior = false;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(588, 23);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(113, 23);
            this.btnRefresh.TabIndex = 1;
            this.btnRefresh.Text = "Refresh Lists";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // lnkInventory
            // 
            this.lnkInventory.AutoSize = true;
            this.lnkInventory.Location = new System.Drawing.Point(13, 9);
            this.lnkInventory.Name = "lnkInventory";
            this.lnkInventory.Size = new System.Drawing.Size(51, 13);
            this.lnkInventory.TabIndex = 2;
            this.lnkInventory.TabStop = true;
            this.lnkInventory.Text = "Inventory";
            // 
            // frmViewOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(739, 408);
            this.Controls.Add(this.lnkInventory);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.tabPackList);
            this.Name = "frmViewOrder";
            this.Text = "Shipping Orders";
            this.tabPackList.ResumeLayout(false);
            this.tabAllOrders.ResumeLayout(false);
            this.tabPickList.ResumeLayout(false);
            this.tabMyOrders.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabPackList;
        private System.Windows.Forms.TabPage tabAllOrders;
        private System.Windows.Forms.TabPage tabPickList;
        private System.Windows.Forms.TabPage tabMyOrders;
        private System.Windows.Forms.ListView lvAllOrders;
        private System.Windows.Forms.ListView lvPickList;
        private System.Windows.Forms.Button btnStartPick;
        private System.Windows.Forms.Button btnDetails;
        private System.Windows.Forms.ListView lvMyOrders;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnPackComplete;
        private System.Windows.Forms.ListView lvPackList;
        private System.Windows.Forms.Button btnClearUser;
        private System.Windows.Forms.LinkLabel lnkInventory;

    }
}