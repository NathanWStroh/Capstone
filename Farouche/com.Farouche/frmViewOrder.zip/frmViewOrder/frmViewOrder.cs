﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using com.Farouche.BusinessLogic;
using com.Farouche.Commons;
//Author: Ben Grimes
//Created: 3/5/14
//Last Edited By:
//Last Edited Date:

namespace com.Farouche
{
    public partial class frmViewOrder : Form
    {
        private readonly AccessToken _myAccessToken;
        private ShippingOrderManager _myOrderManager;

        public frmViewOrder(AccessToken acctoken)
        {
            InitializeComponent();
            _myAccessToken = acctoken;
            _myOrderManager = new ShippingOrderManager();
        }//End of frmViewOrder(.)

        private void frmViewOrder_Load(object sender, EventArgs e)
        {
            Text += "                         " + _myAccessToken.FirstName + " " + _myAccessToken.LastName + " logged in as a " + _myAccessToken.Title;
            //Refreshes the listviews
            refresh();
        }//frmAddProduct_Load(..)

        private void refresh()
        {
            populateListView(lvAllOrders, _myOrderManager.GetAllShippingOrders());
            populateListView(lvPickList, _myOrderManager.GetNonPickedOrders());
            populateListView(lvMyOrders, _myOrderManager.GetOrdersByUserId(_myAccessToken.UserID));
            populateListView(lvPackList, _myOrderManager.GetPickedOrders());
        }//End of refresh()

        private void populateListView(ListView lv, List<ShippingOrder> orderList)
        {
            lv.Items.Clear();
            lv.Columns.Clear();
            foreach (var order in orderList)
            {
                var item = new ListViewItem();
                item.Text = order.ID.ToString();
                item.SubItems.Add(order.ShippingVendorName);
                item.SubItems.Add(order.Picked.ToString());
                lv.Items.Add(item);
            }
            lv.Columns.Add("OrderID");
            lv.Columns.Add("Vendor");
            lv.Columns.Add("Picked");
            lv.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
        }//End of populateListView(..)

        private void btnDetails_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedOrder = this.lvMyOrders.Items[0].Index;
                frmViewOrderDetails myForm = new frmViewOrderDetails(_myOrderManager.Orders[selectedOrder]);
                myForm.Show();
                Hide();
            }
            catch
            {
                MessageBox.Show("Please select an order from the list", "No Order Selected");
            }
        }//End btnDetails(..)

        private void btnStartPick_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedOrder = this.lvPickList.Items[0].Index;
                Boolean success = _myOrderManager.UpdateUserId(_myOrderManager.Orders[selectedOrder], _myAccessToken.UserID);
                if (success == true)
                {
                    frmViewOrderDetails myForm = new frmViewOrderDetails(_myOrderManager.Orders[selectedOrder]);
                    myForm.Show();
                    Hide();
                }
                else
                {
                    MessageBox.Show("Order already taken by another employee", "Please Refresh");
                }
            }
            catch
            {
                MessageBox.Show("Please select an order from the list", "No Order Selected");
            }
        }//End btnStartPick(..)

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            refresh();
        }//End btnRefresh(..)

        private void btnPackComplete_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedOrder = this.lvPackList.Items[0].Index;
                Boolean success = _myOrderManager.UpdateShippedDate(_myOrderManager.Orders[selectedOrder]);
                if (success == true)
                {
                    MessageBox.Show("Now Printing Pack Slip", "Packing Complete");
                }
                else
                {
                    MessageBox.Show("Cannot complete action.", "Please Refresh");
                }
            }
            catch
            {
                MessageBox.Show("Please select an order from the list", "No Order Selected");
            }
        }

        private void btnClearUser_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedOrder = this.lvAllOrders.Items[0].Index;
                Boolean success = _myOrderManager.ClearUserId(_myOrderManager.Orders[selectedOrder]);
                if (success == true)
                {
                    MessageBox.Show("EmployeeID removed from selected order.", "Action Complete");
                }
                else
                {
                    MessageBox.Show("Cannot complete action.", "Please Refresh");
                }
            }
            catch
            {
                MessageBox.Show("Please select an order from the list", "No Order Selected");
            }
        }//End btnPackComplete(..)
    }
}
