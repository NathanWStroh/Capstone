﻿namespace com.Farouche.Presentation
{
    partial class FrmVendor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpAddVendor = new System.Windows.Forms.TabPage();
            this.cbVendorCountry = new System.Windows.Forms.ComboBox();
            this.cbVendorState = new System.Windows.Forms.ComboBox();
            this.txtVendorContactPhone = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtVendorContactEmail = new System.Windows.Forms.TextBox();
            this.btnAddNewVendor = new System.Windows.Forms.Button();
            this.txtVendorContact = new System.Windows.Forms.TextBox();
            this.txtVendorID = new System.Windows.Forms.TextBox();
            this.txtVendorZipCode = new System.Windows.Forms.TextBox();
            this.txtVendorCity = new System.Windows.Forms.TextBox();
            this.txtVendorAddress = new System.Windows.Forms.TextBox();
            this.txtVendorName = new System.Windows.Forms.TextBox();
            this.lblVendorPhone = new System.Windows.Forms.Label();
            this.lblVendorContactEmail = new System.Windows.Forms.Label();
            this.lblVendorContact = new System.Windows.Forms.Label();
            this.lblVendorID = new System.Windows.Forms.Label();
            this.lblVendorZipCode = new System.Windows.Forms.Label();
            this.lblVendorCountry = new System.Windows.Forms.Label();
            this.lblVendorState = new System.Windows.Forms.Label();
            this.lblVendorCity = new System.Windows.Forms.Label();
            this.lblVendorAddress = new System.Windows.Forms.Label();
            this.lblVendorName = new System.Windows.Forms.Label();
            this.tpDeactivateVendor = new System.Windows.Forms.TabPage();
            this.tpUpdateVendor = new System.Windows.Forms.TabPage();
            this.tpShowVendors = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.txtVendors = new System.Windows.Forms.TextBox();
            this.tpShowProducts = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.txtProducts = new System.Windows.Forms.TextBox();
            this.btnProduct = new System.Windows.Forms.Button();
            this.btnVendorSource = new System.Windows.Forms.Button();
            this.btnPressed = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tpAddVendor.SuspendLayout();
            this.tpShowVendors.SuspendLayout();
            this.tpShowProducts.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpAddVendor);
            this.tabControl1.Controls.Add(this.tpDeactivateVendor);
            this.tabControl1.Controls.Add(this.tpUpdateVendor);
            this.tabControl1.Controls.Add(this.tpShowVendors);
            this.tabControl1.Controls.Add(this.tpShowProducts);
            this.tabControl1.Location = new System.Drawing.Point(26, 26);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(780, 350);
            this.tabControl1.TabIndex = 0;
            // 
            // tpAddVendor
            // 
            this.tpAddVendor.Controls.Add(this.cbVendorCountry);
            this.tpAddVendor.Controls.Add(this.cbVendorState);
            this.tpAddVendor.Controls.Add(this.txtVendorContactPhone);
            this.tpAddVendor.Controls.Add(this.btnClear);
            this.tpAddVendor.Controls.Add(this.txtVendorContactEmail);
            this.tpAddVendor.Controls.Add(this.btnAddNewVendor);
            this.tpAddVendor.Controls.Add(this.txtVendorContact);
            this.tpAddVendor.Controls.Add(this.txtVendorID);
            this.tpAddVendor.Controls.Add(this.txtVendorZipCode);
            this.tpAddVendor.Controls.Add(this.txtVendorCity);
            this.tpAddVendor.Controls.Add(this.txtVendorAddress);
            this.tpAddVendor.Controls.Add(this.txtVendorName);
            this.tpAddVendor.Controls.Add(this.lblVendorPhone);
            this.tpAddVendor.Controls.Add(this.lblVendorContactEmail);
            this.tpAddVendor.Controls.Add(this.lblVendorContact);
            this.tpAddVendor.Controls.Add(this.lblVendorID);
            this.tpAddVendor.Controls.Add(this.lblVendorZipCode);
            this.tpAddVendor.Controls.Add(this.lblVendorCountry);
            this.tpAddVendor.Controls.Add(this.lblVendorState);
            this.tpAddVendor.Controls.Add(this.lblVendorCity);
            this.tpAddVendor.Controls.Add(this.lblVendorAddress);
            this.tpAddVendor.Controls.Add(this.lblVendorName);
            this.tpAddVendor.Location = new System.Drawing.Point(4, 22);
            this.tpAddVendor.Name = "tpAddVendor";
            this.tpAddVendor.Padding = new System.Windows.Forms.Padding(3);
            this.tpAddVendor.Size = new System.Drawing.Size(772, 324);
            this.tpAddVendor.TabIndex = 0;
            this.tpAddVendor.Text = "Add Vendor";
            this.tpAddVendor.UseVisualStyleBackColor = true;
            this.tpAddVendor.Click += new System.EventHandler(this.tpAddVendor_Click);
            // 
            // cbVendorCountry
            // 
            this.cbVendorCountry.FormattingEnabled = true;
            this.cbVendorCountry.Location = new System.Drawing.Point(116, 159);
            this.cbVendorCountry.Name = "cbVendorCountry";
            this.cbVendorCountry.Size = new System.Drawing.Size(121, 21);
            this.cbVendorCountry.TabIndex = 4;
            // 
            // cbVendorState
            // 
            this.cbVendorState.FormattingEnabled = true;
            this.cbVendorState.Location = new System.Drawing.Point(116, 126);
            this.cbVendorState.Name = "cbVendorState";
            this.cbVendorState.Size = new System.Drawing.Size(121, 21);
            this.cbVendorState.TabIndex = 3;
            // 
            // txtVendorContactPhone
            // 
            this.txtVendorContactPhone.Location = new System.Drawing.Point(433, 121);
            this.txtVendorContactPhone.Name = "txtVendorContactPhone";
            this.txtVendorContactPhone.Size = new System.Drawing.Size(206, 20);
            this.txtVendorContactPhone.TabIndex = 8;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(569, 286);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 1;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            // 
            // txtVendorContactEmail
            // 
            this.txtVendorContactEmail.Location = new System.Drawing.Point(433, 91);
            this.txtVendorContactEmail.Name = "txtVendorContactEmail";
            this.txtVendorContactEmail.Size = new System.Drawing.Size(206, 20);
            this.txtVendorContactEmail.TabIndex = 7;
            // 
            // btnAddNewVendor
            // 
            this.btnAddNewVendor.Location = new System.Drawing.Point(650, 286);
            this.btnAddNewVendor.Name = "btnAddNewVendor";
            this.btnAddNewVendor.Size = new System.Drawing.Size(100, 23);
            this.btnAddNewVendor.TabIndex = 1;
            this.btnAddNewVendor.Text = "Add Vendor";
            this.btnAddNewVendor.UseVisualStyleBackColor = true;
            this.btnAddNewVendor.Click += new System.EventHandler(this.btnAddNewVendor_Click);
            // 
            // txtVendorContact
            // 
            this.txtVendorContact.Location = new System.Drawing.Point(433, 59);
            this.txtVendorContact.Name = "txtVendorContact";
            this.txtVendorContact.Size = new System.Drawing.Size(206, 20);
            this.txtVendorContact.TabIndex = 6;
            // 
            // txtVendorID
            // 
            this.txtVendorID.Enabled = false;
            this.txtVendorID.Location = new System.Drawing.Point(433, 21);
            this.txtVendorID.Name = "txtVendorID";
            this.txtVendorID.Size = new System.Drawing.Size(206, 20);
            this.txtVendorID.TabIndex = 14;
            // 
            // txtVendorZipCode
            // 
            this.txtVendorZipCode.Location = new System.Drawing.Point(116, 197);
            this.txtVendorZipCode.Name = "txtVendorZipCode";
            this.txtVendorZipCode.Size = new System.Drawing.Size(206, 20);
            this.txtVendorZipCode.TabIndex = 5;
            // 
            // txtVendorCity
            // 
            this.txtVendorCity.Location = new System.Drawing.Point(116, 91);
            this.txtVendorCity.Name = "txtVendorCity";
            this.txtVendorCity.Size = new System.Drawing.Size(206, 20);
            this.txtVendorCity.TabIndex = 2;
            // 
            // txtVendorAddress
            // 
            this.txtVendorAddress.Location = new System.Drawing.Point(116, 59);
            this.txtVendorAddress.Name = "txtVendorAddress";
            this.txtVendorAddress.Size = new System.Drawing.Size(206, 20);
            this.txtVendorAddress.TabIndex = 1;
            // 
            // txtVendorName
            // 
            this.txtVendorName.Location = new System.Drawing.Point(116, 28);
            this.txtVendorName.Name = "txtVendorName";
            this.txtVendorName.Size = new System.Drawing.Size(206, 20);
            this.txtVendorName.TabIndex = 0;
            // 
            // lblVendorPhone
            // 
            this.lblVendorPhone.AutoSize = true;
            this.lblVendorPhone.Location = new System.Drawing.Point(358, 121);
            this.lblVendorPhone.Name = "lblVendorPhone";
            this.lblVendorPhone.Size = new System.Drawing.Size(41, 13);
            this.lblVendorPhone.TabIndex = 9;
            this.lblVendorPhone.Text = "Phone:";
            // 
            // lblVendorContactEmail
            // 
            this.lblVendorContactEmail.AutoSize = true;
            this.lblVendorContactEmail.Location = new System.Drawing.Point(352, 94);
            this.lblVendorContactEmail.Name = "lblVendorContactEmail";
            this.lblVendorContactEmail.Size = new System.Drawing.Size(75, 13);
            this.lblVendorContactEmail.TabIndex = 8;
            this.lblVendorContactEmail.Text = "Contact Email:";
            // 
            // lblVendorContact
            // 
            this.lblVendorContact.AutoSize = true;
            this.lblVendorContact.Location = new System.Drawing.Point(352, 62);
            this.lblVendorContact.Name = "lblVendorContact";
            this.lblVendorContact.Size = new System.Drawing.Size(47, 13);
            this.lblVendorContact.TabIndex = 7;
            this.lblVendorContact.Text = "Contact:";
            // 
            // lblVendorID
            // 
            this.lblVendorID.AutoSize = true;
            this.lblVendorID.Location = new System.Drawing.Point(352, 28);
            this.lblVendorID.Name = "lblVendorID";
            this.lblVendorID.Size = new System.Drawing.Size(58, 13);
            this.lblVendorID.TabIndex = 6;
            this.lblVendorID.Text = "Vendor ID:";
            // 
            // lblVendorZipCode
            // 
            this.lblVendorZipCode.AutoSize = true;
            this.lblVendorZipCode.Location = new System.Drawing.Point(34, 204);
            this.lblVendorZipCode.Name = "lblVendorZipCode";
            this.lblVendorZipCode.Size = new System.Drawing.Size(53, 13);
            this.lblVendorZipCode.TabIndex = 5;
            this.lblVendorZipCode.Text = "Zip Code:";
            // 
            // lblVendorCountry
            // 
            this.lblVendorCountry.AutoSize = true;
            this.lblVendorCountry.Location = new System.Drawing.Point(34, 168);
            this.lblVendorCountry.Name = "lblVendorCountry";
            this.lblVendorCountry.Size = new System.Drawing.Size(46, 13);
            this.lblVendorCountry.TabIndex = 4;
            this.lblVendorCountry.Text = "Country:";
            // 
            // lblVendorState
            // 
            this.lblVendorState.AutoSize = true;
            this.lblVendorState.Location = new System.Drawing.Point(34, 135);
            this.lblVendorState.Name = "lblVendorState";
            this.lblVendorState.Size = new System.Drawing.Size(35, 13);
            this.lblVendorState.TabIndex = 3;
            this.lblVendorState.Text = "State:";
            // 
            // lblVendorCity
            // 
            this.lblVendorCity.AutoSize = true;
            this.lblVendorCity.Location = new System.Drawing.Point(34, 94);
            this.lblVendorCity.Name = "lblVendorCity";
            this.lblVendorCity.Size = new System.Drawing.Size(27, 13);
            this.lblVendorCity.TabIndex = 2;
            this.lblVendorCity.Text = "City:";
            // 
            // lblVendorAddress
            // 
            this.lblVendorAddress.AutoSize = true;
            this.lblVendorAddress.Location = new System.Drawing.Point(34, 62);
            this.lblVendorAddress.Name = "lblVendorAddress";
            this.lblVendorAddress.Size = new System.Drawing.Size(48, 13);
            this.lblVendorAddress.TabIndex = 1;
            this.lblVendorAddress.Text = "Address:";
            // 
            // lblVendorName
            // 
            this.lblVendorName.AutoSize = true;
            this.lblVendorName.Location = new System.Drawing.Point(34, 28);
            this.lblVendorName.Name = "lblVendorName";
            this.lblVendorName.Size = new System.Drawing.Size(75, 13);
            this.lblVendorName.TabIndex = 0;
            this.lblVendorName.Text = "Vendor Name:";
            // 
            // tpDeactivateVendor
            // 
            this.tpDeactivateVendor.Location = new System.Drawing.Point(4, 22);
            this.tpDeactivateVendor.Name = "tpDeactivateVendor";
            this.tpDeactivateVendor.Padding = new System.Windows.Forms.Padding(3);
            this.tpDeactivateVendor.Size = new System.Drawing.Size(772, 324);
            this.tpDeactivateVendor.TabIndex = 1;
            this.tpDeactivateVendor.Text = "Deactivate Vendor";
            this.tpDeactivateVendor.UseVisualStyleBackColor = true;
            // 
            // tpUpdateVendor
            // 
            this.tpUpdateVendor.Location = new System.Drawing.Point(4, 22);
            this.tpUpdateVendor.Name = "tpUpdateVendor";
            this.tpUpdateVendor.Padding = new System.Windows.Forms.Padding(3);
            this.tpUpdateVendor.Size = new System.Drawing.Size(772, 324);
            this.tpUpdateVendor.TabIndex = 2;
            this.tpUpdateVendor.Text = "Update Vendor";
            this.tpUpdateVendor.UseVisualStyleBackColor = true;
            // 
            // tpShowVendors
            // 
            this.tpShowVendors.Controls.Add(this.label1);
            this.tpShowVendors.Controls.Add(this.txtVendors);
            this.tpShowVendors.Location = new System.Drawing.Point(4, 22);
            this.tpShowVendors.Name = "tpShowVendors";
            this.tpShowVendors.Size = new System.Drawing.Size(772, 324);
            this.tpShowVendors.TabIndex = 0;
            this.tpShowVendors.Text = "Show Vendors";
            this.tpShowVendors.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Vendors:";
            // 
            // txtVendors
            // 
            this.txtVendors.Location = new System.Drawing.Point(7, 30);
            this.txtVendors.Multiline = true;
            this.txtVendors.Name = "txtVendors";
            this.txtVendors.Size = new System.Drawing.Size(660, 189);
            this.txtVendors.TabIndex = 0;
            // 
            // tpShowProducts
            // 
            this.tpShowProducts.Controls.Add(this.label2);
            this.tpShowProducts.Controls.Add(this.txtProducts);
            this.tpShowProducts.Location = new System.Drawing.Point(4, 22);
            this.tpShowProducts.Name = "tpShowProducts";
            this.tpShowProducts.Padding = new System.Windows.Forms.Padding(3);
            this.tpShowProducts.Size = new System.Drawing.Size(772, 324);
            this.tpShowProducts.TabIndex = 3;
            this.tpShowProducts.Text = "Show Products";
            this.tpShowProducts.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Products:";
            // 
            // txtProducts
            // 
            this.txtProducts.Location = new System.Drawing.Point(8, 32);
            this.txtProducts.Multiline = true;
            this.txtProducts.Name = "txtProducts";
            this.txtProducts.Size = new System.Drawing.Size(660, 189);
            this.txtProducts.TabIndex = 2;
            // 
            // btnProduct
            // 
            this.btnProduct.Location = new System.Drawing.Point(108, 399);
            this.btnProduct.Name = "btnProduct";
            this.btnProduct.Size = new System.Drawing.Size(90, 23);
            this.btnProduct.TabIndex = 6;
            this.btnProduct.Text = "Product";
            this.btnProduct.UseVisualStyleBackColor = true;
            this.btnProduct.Click += new System.EventHandler(this.btnProduct_Click);
            // 
            // btnVendorSource
            // 
            this.btnVendorSource.Location = new System.Drawing.Point(204, 399);
            this.btnVendorSource.Name = "btnVendorSource";
            this.btnVendorSource.Size = new System.Drawing.Size(90, 23);
            this.btnVendorSource.TabIndex = 7;
            this.btnVendorSource.Text = "Vendor Source";
            this.btnVendorSource.UseVisualStyleBackColor = true;
            this.btnVendorSource.Click += new System.EventHandler(this.btnVendorSource_Click);
            // 
            // btnPressed
            // 
            this.btnPressed.Enabled = false;
            this.btnPressed.Location = new System.Drawing.Point(12, 399);
            this.btnPressed.Name = "btnPressed";
            this.btnPressed.Size = new System.Drawing.Size(90, 23);
            this.btnPressed.TabIndex = 8;
            this.btnPressed.Text = "Vendor";
            this.btnPressed.UseVisualStyleBackColor = true;
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(747, 402);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 9;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // frmVendor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 437);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnPressed);
            this.Controls.Add(this.btnVendorSource);
            this.Controls.Add(this.btnProduct);
            this.Controls.Add(this.tabControl1);
            this.Name = "FrmVendor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vendor";
            this.Load += new System.EventHandler(this.frmVendor_Load);
            this.tabControl1.ResumeLayout(false);
            this.tpAddVendor.ResumeLayout(false);
            this.tpAddVendor.PerformLayout();
            this.tpShowVendors.ResumeLayout(false);
            this.tpShowVendors.PerformLayout();
            this.tpShowProducts.ResumeLayout(false);
            this.tpShowProducts.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpAddVendor;
        private System.Windows.Forms.TabPage tpDeactivateVendor;
        private System.Windows.Forms.TabPage tpUpdateVendor;
        private System.Windows.Forms.Label lblVendorContactEmail;
        private System.Windows.Forms.Label lblVendorContact;
        private System.Windows.Forms.Label lblVendorID;
        private System.Windows.Forms.Label lblVendorZipCode;
        private System.Windows.Forms.Label lblVendorCountry;
        private System.Windows.Forms.Label lblVendorState;
        private System.Windows.Forms.Label lblVendorCity;
        private System.Windows.Forms.Label lblVendorAddress;
        private System.Windows.Forms.Label lblVendorName;
        private System.Windows.Forms.TextBox txtVendorContactEmail;
        private System.Windows.Forms.TextBox txtVendorContact;
        private System.Windows.Forms.TextBox txtVendorID;
        private System.Windows.Forms.TextBox txtVendorZipCode;
        private System.Windows.Forms.TextBox txtVendorCity;
        private System.Windows.Forms.TextBox txtVendorAddress;
        private System.Windows.Forms.TextBox txtVendorName;
        private System.Windows.Forms.Label lblVendorPhone;
        private System.Windows.Forms.ComboBox cbVendorCountry;
        private System.Windows.Forms.ComboBox cbVendorState;
        private System.Windows.Forms.TextBox txtVendorContactPhone;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnAddNewVendor;
        private System.Windows.Forms.TabPage tpShowVendors;
        private System.Windows.Forms.TextBox txtVendors;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tpShowProducts;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtProducts;
        private System.Windows.Forms.Button btnProduct;
        private System.Windows.Forms.Button btnVendorSource;
        private System.Windows.Forms.Button btnPressed;
        private System.Windows.Forms.Button btnLogout;
    }
}

