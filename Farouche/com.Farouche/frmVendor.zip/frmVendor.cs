﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using com.Farouche.Commmons;
using com.Farouche.BusinessLogic;

//Author: Andrew
//Date Created: 1/31/2014
//Last Modified: 02/7/2014 
//Last Modified By: Adam Chandler

/*
*                               Changelog
* Date         By          Ticket          Version         Description
* 02/7/2014   Adam                          0.0.1b         Updated Instantiation of new objects to use id as parameter
*/
namespace com.Farouche.Presentation
//namespace CapstoneProject
{
    public partial class FrmVendor : Form
    {
        private readonly AccessToken _myAccessToken;
        private VendorManager _vendorManager;
        //private ProductBLL productManager;

        public FrmVendor(AccessToken acctoken)
        {
            InitializeComponent();
            _myAccessToken = acctoken;
        }

        private void frmVendor_Load(object sender, EventArgs e)
        {
            Text += "                         " + _myAccessToken.FirstName + " " + _myAccessToken.LastName + " logged in as a " + _myAccessToken.Title;
            
            _vendorManager = new VendorManager();
           // productManager = new ProductBLL();
            showVendors();
            showProducts();
        }

        // don't know how to get rid of this, so I just commented out the code inside
        private void tpAddVendor_Click(object sender, EventArgs e)
        {
           // tpAddVendor.Controls.Add(lblVendorName);  
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnAddNewVendor_Click(object sender, EventArgs e)
        {
            addVendor();
        }

        private void addVendor()
        {
            string name = txtVendorName.Text;
            string address = txtVendorAddress.Text;
            string city = txtVendorCity.Text;
           // string state = cbVendorState.SelectedText.Trim();
            string state = cbVendorState.Text;
            string zip = txtVendorZipCode.Text;
            string country = cbVendorCountry.Text;
            string phone = txtVendorContactPhone.Text;
            string contact = txtVendorContact.Text;
            string email = txtVendorContactEmail.Text;


         //   Console.WriteLine("Here: " + name + " " + address  + " " + city  + " " + state + " " + zip  + " " + country  + " " + phone  + " " + contact  + " " + email  );
            Vendor vendor = new Vendor(0)
            {
                Name = name,
                Address = address,
                City = city,
                State = state,
                Country = country,
                Zip = zip,
                Phone = phone,
                Contact = contact,
                ContactEmail = email
            };

            bool success = _vendorManager.AddVendor(vendor);

            if (success == true)
            {
                MessageBox.Show(name + " was added");
            }
            else
            {
                MessageBox.Show(name + " was not added, sorry bro");
            }

            
        }

        private void showVendors()
        {
            string vendorListString = "";
          
            List<Vendor> vendorList = new List<Vendor>();

            vendorList = _vendorManager.GetVendors();

            foreach (Vendor v in vendorList)
            {
              vendorListString = vendorListString + (v.ToString() + "\r\n");
            }

            txtVendors.Text = vendorListString;
        }

        private void showProducts()
        {
            //string productListString = "";
            //List<Product2> productList = new List<Product2>();

            //productList = productManager.getProducts();

            //foreach (Product2 p in productList)
            //{ 
            //productListString = productListString + (p.toString() + "\r\n");
            //}

            //Console.WriteLine(productListString);
            //txtProducts.Text = productListString;

        }



        private void btnProduct_Click(object sender, EventArgs e)
        {
            FrmProduct myform = new FrmProduct(_myAccessToken);
            myform.Show();
            Close();
        }


        private void btnVendorSource_Click(object sender, EventArgs e)
        {
            FrmVendorSource form = new FrmVendorSource(_myAccessToken);
            form.Show();
            Close();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            FrmLogin frm = new FrmLogin();
            frm.Show();
            Close();
        }





        
    }
}
