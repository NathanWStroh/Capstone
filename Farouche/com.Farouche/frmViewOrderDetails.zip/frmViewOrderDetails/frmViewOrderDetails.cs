﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using com.Farouche.BusinessLogic;
using com.Farouche.Commons;
using System.Drawing.Printing;
//Author: Ben Grimes
//Created: 3/5/14
//Last Edited By:
//Last Edited Date:

namespace com.Farouche
{
    public partial class frmViewOrderDetails : Form
    {
        private ShippingOrderLineItemManager _myOrderDetails;
        private ShippingOrderManager _myOrderManager;
        private ShippingOrder _myOrder;

        public frmViewOrderDetails(ShippingOrder order)
        {
            InitializeComponent();
            _myOrder = order;
            _myOrderDetails = new ShippingOrderLineItemManager();
        }

        public void frmViewOrderDetails_Load(object sender, EventArgs e)
        {
            populateListView(lvItemsForPick, _myOrderDetails.GetShippingOrderLineItemByPick(_myOrder, false));
        }

        private void populateListView(ListView lv, List<ShippingOrderLineItem> orderItemList)
        {
            foreach (var orderItem in orderItemList)
            {
                lv.Items.Clear();
                lv.Columns.Clear();
                var item = new ListViewItem();
                item.Text = orderItem.ProductId.ToString();
                item.SubItems.Add(orderItem.ProductName);
                item.SubItems.Add(orderItem.Quantity.ToString());
                item.SubItems.Add(orderItem.ProductLocation);
                lv.Items.Add(item);
            }
            lv.Columns.Add("ProductID");
            lv.Columns.Add("Name");
            lv.Columns.Add("Quantity");
            lv.Columns.Add("Location");
            lv.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
        }//End of populateListView(..)

        private void btnPrintDetails_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Printing order details to nearest printer...", "Printing");
        }//End of btnPrintDetails(..)

        private void btnComplete_Click(object sender, EventArgs e)
        {
            Boolean success = _myOrderManager.UpdatePickedTrue(_myOrder);
            if (success == true)
            {
                if(lvItemsForPick.Items.Count.Equals(0))
                {
                    MessageBox.Show("Order has been sent to packing queue", "Ready for Packing");
                }
                else
                {
                    MessageBox.Show("Not all items for this order have been picked", "Slacker!");
                }
            }
            else
            { 
                MessageBox.Show("Action Could Not Be Completed", "Error");
            }
        }//End of btnComplete(..)

        private void btnPick_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedItem = this.lvItemsForPick.Items[0].Index;
                Boolean success = _myOrderDetails.UpdatePickedTrue(_myOrderDetails.LineItems[selectedItem]);
                if (success == true)
                {
                    populateListView(lvItemsForPick, _myOrderDetails.GetShippingOrderLineItemByPick(_myOrder, false));
                }
                else
                {
                    MessageBox.Show("Action could not be completed", "Error");
                }
            }
            catch
            {
                MessageBox.Show("Please select an item from the list", "No Item Selected");
            }
        }//End of btnPick(..)
    }
}
